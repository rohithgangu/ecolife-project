import React from "react";

import "../assets/css/style.min.css";
import "../assets/css/responsive.min.css";
import "../assets/css/vendor/plugins.min.css";
import "D:/internship/B2b/ecolife/node_modules/font-awesome/css/font-awesome.min.css";

import ProductDataService from "../services/products.js"
import { useEffect,useState } from "react";

const SingleProduct =(props)=> {
   
 return(
     <p>hello</p>
    
 );
}
export default SingleProduct;